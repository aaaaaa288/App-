# Universal ESP Overlay — iOS source project

This source wraps the standalone HTML preview in a native iOS app using WKWebView.

## Build an IPA
1. On a Mac, install/open Xcode.
2. Create a new iOS App project named `UniversalESPOverlay` (SwiftUI).
3. Replace the generated app Swift file with `UniversalESPOverlayApp.swift`.
4. Add `index.html` to the app target and ensure **Copy Bundle Resources** includes it.
5. Choose your own Apple development team under Signing & Capabilities.
6. Build/archive the app in Xcode, then export an IPA using the available distribution/signing workflow.

## Limitations
This is a visual demo only. It draws sample boxes and lines inside its own app window. It does not detect game players, read game memory, inject into other apps, or display as a system-wide overlay. An IPA must be built and signed using Apple's iOS toolchain; this source archive is not itself an IPA.
